// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compress header block\n", stdout);
  return lionss_run_workload("h2-hpack");
}
