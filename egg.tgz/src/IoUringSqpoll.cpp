// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Poll submission queue"); }
int main(){
  announce();
  return lionss_run_workload("IoUringSqpoll");
}
