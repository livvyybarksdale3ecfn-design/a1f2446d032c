// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Merge profile data"); }
int main(){
  announce();
  return lionss_run_workload("pgo-merge");
}
